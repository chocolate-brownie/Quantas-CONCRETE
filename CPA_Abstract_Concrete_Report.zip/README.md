# CPA Abstract–Concrete comparison report

Upload `CPA_Abstract_Concrete_Report.zip` to Overleaf using **New Project → Upload Project**. The root file is `main.tex`; select **pdfLaTeX** if Overleaf asks for a compiler. The project compiles with visible figure placeholders before you add any graphs.

## Write the report

- Edit the title and author in `main.tex`.
- Edit `sections/experimental_setup.tex` for the setup and metric definitions.
- Write the edge remover analysis in `sections/edge_remover.tex`.
- Add later topology results to `sections/erdos_renyi.tex` and `sections/random_regular.tex`.
- Add citations to `references.bib` and cite them with `\cite{key}`.

Each results subsection has space for a question, figure, observations with numbers, and a cautious interpretation. Replace the instructional text as you write.

## Add graphs

The ZIP contains **no graph data or SVGs**. Upload a figure PDF to the path named in its `\reportfigure` call; the placeholder will be replaced automatically. For example, export `termination_box.svg` as `termination.pdf` and upload it to `figures/edge_remover/`.

Overleaf's standard pdfLaTeX build includes PDF, PNG, and JPEG figures directly. Keep an SVG as your editable source and export a PDF copy for the report. In Inkscape, open the SVG, choose **File → Save As**, and select **Portable Document Format**. You can also use:

```bash
inkscape termination_box.svg --export-filename=termination.pdf
```

Abstract completion uses `completion_abstract.pdf` (logical rounds); Concrete completion uses `completion_concrete.pdf` (milliseconds). Keep these as separate figures because their units differ. If you rename a PDF, update the matching path in the `\reportfigure` call.

The `figures/erdos_renyi/` and `figures/random_regular/` folders are ready for future results. Raw CSVs and existing graphs are intentionally left outside this project.
